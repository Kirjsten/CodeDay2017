/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanenvy.editable;

/**
 *
 * @author Kirjsten
 */
public class ScanENVYEditable {

   /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //implement user interface
        Display display= new Display();
        display.setVisible(true);
        
        // TODO code application logic here
    }
    
}

